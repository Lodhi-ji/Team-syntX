const express = require('express');
const path = require('path');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const saltRounds = 10;

const app = express();
const port = 3000;

// PostgreSQL configuration
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'CodeSprint_DB',
  password: 'Suyash@15',
  port: 1504,
});

// Test database connection
pool.query('SELECT NOW()', (err, res) => {
  if (err) {
    console.error('Database connection error:', err);
  } else {
    console.log('Database connected successfully!');
  }
});

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(__dirname));

// Add Session Middleware
const session = require('express-session');
app.use(session({
  secret: 'your_secret_key', // use a strong secret in production!
  resave: false,
  saveUninitialized: false
}));

// Serve signup page
app.get(['/signup', '/signUp'], (req, res) => {
  res.sendFile(path.join(__dirname, 'sign_up.html'));
});

// Serve login page
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

// Serve mediator page
app.get('/setup-profile-mediator', requireLogin, (req, res) => {
  res.sendFile(path.join(__dirname, 'mediator.html'));
});

// Handle skip profile setup
app.post('/skip-profile-setup', requireLogin, async (req, res) => {
  try {
    await pool.query('UPDATE users SET profile_setup = TRUE WHERE username = $1', [req.session.userId]);
    // Update session if needed
    res.redirect('/');
  } catch (error) {
    console.error('Error updating profile_setup:', error);
    res.redirect('/setup-profile-mediator');
  }
});

// Handle login POST
app.post('/login', async (req, res) => {
  const { username_or_email, password } = req.body;
 
  const userResult = await pool.query('SELECT * FROM users WHERE username = $1 OR email = $1', [username_or_email]);
  if (userResult.rows.length === 0) {
    return res.redirect('/login-error'); 
  }
  const user = userResult.rows[0];
  const match = await bcrypt.compare(password, user.password);
  if (!match) {
    return res.redirect('/login-error'); 
  }
  req.session.userId = user.username;
  req.session.role = user.role;
  
  console.log('User profile_setup:', user.profile_setup);
  
  if (!user.profile_setup) {
    return res.redirect('/setup-profile-mediator');
  }
  res.redirect('/');
});

app.get('/login-error', (req, res) => {
  res.sendFile(path.join(__dirname, 'login_error.html'));
});

app.post('/signup', async (req, res) => {
  try {
    const { name, username, email, password, confirm_password } = req.body;
    if (password !== confirm_password) {
      return res.redirect('/signup');
    }

    const checkUsername = await pool.query('SELECT * FROM users WHERE username = $1', [username]);
    if (checkUsername.rows.length > 0) {
      return res.redirect('/signup');
    }
   
    const checkEmail = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (checkEmail.rows.length > 0) {
      return res.redirect('/signup');
    }
    // Insert new user
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    await pool.query(
      'INSERT INTO users (username, full_name, email, password) VALUES ($1, $2, $3, $4)',
      [username, name, email, hashedPassword]
    );
    // Set session and redirect to mediator after successful signup
    req.session.userId = username;
    req.session.role = 'user'; // Default role, adjust if needed
    res.redirect('/setup-profile-mediator');
  } catch (error) {
    console.error('Database error:', error);
    res.redirect('/signup');
  }
});

// Serve homepage (for Back to Home)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'homepage.html'));
});

// Serve profile and settings pages
app.get('/profile', (req, res) => {
  res.sendFile(path.join(__dirname, 'profile.html'));
});
app.get('/settings', (req, res) => {
  res.sendFile(path.join(__dirname, 'settings.html'));
});

// Real logout logic
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

// Protect routes
function requireLogin(req, res, next) {
  if (!req.session.userId) {
    return res.redirect('/exclusive');
  }
  next();
}

// Example usage:
app.get('/dashboard', requireLogin, (req, res) => {
  // Only logged-in users can access
});

// Protect ask question route
app.get(['/ask', '/ask-question'], requireLogin, (req, res) => {
  res.sendFile(path.join(__dirname, 'askquestion.html'));
});

app.get('/exclusive', (req, res) => {
  res.sendFile(path.join(__dirname, 'exclusive.html'));
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});


