import pg from 'pg';

const db = new pg.Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'stackit',
  password: 'pg@2004',
  port: 5432,
});

async function getQuestions() {
  const res = await db.query(`
    SELECT id, title, description, tags, username, answer_count
    FROM questions
    ORDER BY id DESC
  `);
  return res.rows.map(q => ({
    ...q,
    tags: q.tags ? q.tags.split(',') : [],
  }));
}

export { db, getQuestions };

export async function getQuestionById(id) {
  const res = await db.query('SELECT * FROM questions WHERE id = $1', [id]);
  return res.rows[0];
}

export async function getAnswersByQuestionId(questionId) {
  const res = await db.query(
    'SELECT * FROM answers WHERE question_id = $1 ORDER BY id DESC',
    [questionId]
  );
  return res.rows;
}
