import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { db, getQuestions } from './index.js';
import { getQuestionById, getAnswersByQuestionId } from './index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;


app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.get('/', async (req, res) => {
  const questions = await getQuestions();
  res.render('homepage', { questions });
});

app.get('/ask', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'ask.html')); 
});

app.post('/questions', async (req, res) => {
  const { title, description, tags, username } = req.body;

  if (!title || !username) {
    return res.status(400).send('Title and username are required.');
  }

  try {
    await db.query(
      `INSERT INTO questions (title, description, tags, username)
       VALUES ($1, $2, $3, $4)`,
      [title, description, tags, username]
    );
    res.redirect('/');
  } catch (err) {
    console.error('Insert Error:', err.message);
    res.status(500).send('Failed to insert question.');
  }
});

app.get('/question/:id', async (req, res) => {
  const questionId = req.params.id;

  try {
    const question = await getQuestionById(questionId);
    const answers = await getAnswersByQuestionId(questionId);

    if (!question) {
      return res.status(404).send('Question not found');
    }

    res.render('question-detail', { question, answers }); 
  } catch (err) {
    console.error('Fetch Question Error:', err.message);
    res.status(500).send('Error fetching question');
  }
});


app.post('/questions/:id/answer', async (req, res) => {
  const questionId = req.params.id;
  const { answer_html } = req.body;

  if (!answer_html || !questionId) {
    return res.status(400).send('Missing required data');
  }

  try {
    await pool.query(
      `INSERT INTO answers (question_id, answer_html) VALUES ($1, $2)`,
      [questionId, answer_html]
    );

  
    await pool.query(
      `UPDATE questions SET answer_count = answer_count + 1 WHERE id = $1`,
      [questionId]
    );

    res.redirect(`/question/${questionId}`);
  } catch (err) {
    console.error('Error submitting answer:', err.message);
    res.status(500).send('Failed to post answer');
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
