CREATE TABLE IF NOT EXISTS questions (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  tags TEXT, 
  username TEXT,
  answer_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS answers (
  id SERIAL PRIMARY KEY,
  question_id INTEGER REFERENCES questions(id),
  content TEXT NOT NULL,
  votes INTEGER DEFAULT 0,
  username TEXT
);
